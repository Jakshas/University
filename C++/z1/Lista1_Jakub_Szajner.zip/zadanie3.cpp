#include <iostream>
#include <set>
using namespace std;

using alias =set<string>;
int main(int argc, char const *argv[])
{
    alias zbior{"sassa","saasa","swdaffedswefw","dxwwedadwas","eswfaqeqwfwqsfadc"};
    for(auto s :zbior){
        cout<<s<<" ";
    }
    return 0;
}

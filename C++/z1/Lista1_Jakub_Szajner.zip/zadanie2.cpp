#include <iostream>
using namespace std;
int main(int argc, char const *argv[])
{
    cout<<R"(Instytut Informatyki Uniwersytetu Wrocławskiego 
Fryderyka Joliot-Curie 15 
50-383 Wrocław)"<<endl;
    cout<<R"(C:\Program Files)"<<endl;
    cout<<R"xyz("""(((()"))""")))(()()("())(()"())"("")")xyz";
    return 0;
}

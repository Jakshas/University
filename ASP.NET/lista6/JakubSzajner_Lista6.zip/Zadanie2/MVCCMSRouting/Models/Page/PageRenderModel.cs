﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace MVCCMSRouting.Models.Page
{
    public class PageRenderModel
    {
        public string Site { get; set; }
        public string Page { get; set; }
        public string Content { get; set; }
    }
}
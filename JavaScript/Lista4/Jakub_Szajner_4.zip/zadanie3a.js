console.log("a");

var b=require("./zadanie3b")
var c=require("./zadanie3c")

if(b.done) console.log("b1");
if(c.done) console.log("c1");

console.log("koniec");
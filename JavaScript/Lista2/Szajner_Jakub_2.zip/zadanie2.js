const food = ['apple', 'pizza', 'pear']
var x = {
    foo: 2
    
}
var rt={
    jj:0
}
x.foo = 2
x['foo'] = 2
x['cos'] = 1
x[rt]=2
food['ss']=1
food.length=1
console.log(food[2])
function math(one,two,three) {
    return two*three+one
}
console.log(math(53,61,67))
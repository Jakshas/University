// Jakub Szajner 315700
#include <iostream>
#include <netinet/ip.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sstream>
#include <map>
using namespace std;

int find_first_newline(u_int8_t buffer[]);

void load(char const *argv[], string &ip, int &port, string &file, int64_t &size);

void send_request(int sockfd, int mostlastrecived, int elements, int size, bool* recived,struct sockaddr_in &server_address);
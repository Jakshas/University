// Jakub Szajner 315700
#include "transport.h"

int find_first_newline(u_int8_t buffer[]){
    int i = 0;
    while (buffer[i] != '\n')
    {
        i++;
    }
    return i;
}
void load(char const *argv[], string &ip, int &port, string &file, int64_t &size){
    unsigned char buf[sizeof(struct in6_addr)];
    if(inet_pton(AF_INET, argv[1], buf) <= 0){
            exit(0);
        }
        ip = argv[1];
        port = stoi(argv[2]);
        file = argv[3];
        size = stoi(argv[4]);
}
void send_request(int sockfd, int mostlastrecived, int elements, int size, bool* recived,struct sockaddr_in &server_address){
        for (int i = 1; i < 500 && mostlastrecived + i < elements; i++)
        {
            char* message = new char[50];
            strcpy(message, ("GET " + to_string((mostlastrecived + i)*1000) + " " + to_string((mostlastrecived + i >= elements - 1) ? size % 1000 : 1000) +"\n").c_str());
            ssize_t message_len = strlen(message);
            if (!recived[mostlastrecived + i])
            {
                if (sendto(sockfd, message, message_len, 0, (struct sockaddr*) &server_address, sizeof(server_address)) != message_len) {
                    fprintf(stderr, "sendto error: %s\n", strerror(errno)); 		
                }
            }
            free(message);
        }
}
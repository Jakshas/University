package obliczenia;
import struktury.*;
public class Deklaracja extends Instrukcja{
    String zmienna;

    public Deklaracja(String z) throws Exception {
        if (z==null) {
            throw new Exception("null");
        }
        this.zmienna=z;
    }

    @Override
    public void wykonaj() throws Exception {
        Blok.srodowiska.get(Blok.srodowiska.size()-1).wstaw(new Para(0,zmienna));
    }
    
}

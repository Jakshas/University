package obliczenia;

public interface Wykonywalny {
    public void wykonaj() throws Exception;
}

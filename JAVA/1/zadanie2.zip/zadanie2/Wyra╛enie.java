package zadanie2;

public class Wyrażenie {
    public int oblicz(){
        return 0;
    }
    public String toString(){
        return "";
    }
}
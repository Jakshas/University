package zadanie1;

public class Element{
    T wartosc;
    Element next;
    Element(T w){
        wartosc=w;
        next=null;
    }
}

package zadanie1;

public interface T extends Comparable<T>{
    public int gethardness();
    public int compareTo(T input);
}
public class Klucz extends Przedmiot{
    int rodzaj;
    Klucz(int rodzaj){
        super();
        uzycia=1;
        this.rodzaj=rodzaj;
    }
    @Override
    public void interakcja(Okno ok, int x, int y) {
        int i=0;
        while(i<5&&ok.ekwipunek[i]!=null){
            i++;
        }
        if(i<5){
        ok.ekwipunek[i]=new Klucz(rodzaj);
        ok.plansza[x][y]=new Puste(true);
    }}
}
public class Przedmiot extends Pole{
    int uzycia;
    Przedmiot(){
        super();
        uzycia=2;//(int)(Math.random() * (3)+1);
    }
    @Override
    public void interakcja(Okno ok, int x, int y) {
        
    }
}
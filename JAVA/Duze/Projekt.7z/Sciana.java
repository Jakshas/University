public class Sciana extends Pole{
    int wytrzymalosc;
    public Sciana(){
        super();
        wytrzymalosc=((int)Math.random()%5)+1;
    }
    @Override
    public void interakcja(Okno ok,int x, int y) {
        if(x==0||y==0||x==19||y==19){
        }else{
            int o=ok.szukajki();
            if(o>0){
                wytrzymalosc=-o;
            }
            if(wytrzymalosc<=0){
                ok.plansza[x][y]=new Puste();
            }
        }
    }
}
public class Drzwi extends Pole {
    int klucz;
    public Drzwi(int klucz){
        super();
        this.klucz=klucz;
    }
    @Override
    public void interakcja(Okno ok,int x, int y) {
        if(ok.szukajk(this.klucz)){
            ok.plansza[x][y]=new Puste(true);
        }
    }
}
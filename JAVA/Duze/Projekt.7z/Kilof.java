public class Kilof extends Przedmiot{
    int wydajnosc;
    Kilof(){
        super();
        wydajnosc=(int)(Math.random() * ((3-1) + 1))+1;
    }
    Kilof(int wydajnosc){
        super();
        this.wydajnosc=wydajnosc;
    }
    @Override
    public void interakcja(Okno ok, int x, int y) {
        int i=0;
        while(i<5&&ok.ekwipunek[i]!=null){
            i++;
        }if(i<5){
        ok.ekwipunek[i]=new Kilof(wydajnosc);
        ok.plansza[x][y]=new Puste(true);
    }}
}
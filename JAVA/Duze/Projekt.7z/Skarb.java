import javax.swing.*;

public class Skarb extends Pole {
    Skarb(){

    }
    @Override
    public void interakcja(Okno ok, int x, int y) {
        //custom title, no icon
        JOptionPane.showMessageDialog(ok.frame,
        "Znalazłeś skarb. Wygrałeś/aś",
        "Koniec gry",
        JOptionPane.PLAIN_MESSAGE);
        System.exit(0);
    }
}
public class Gracz extends Pole{
    int zdrowie;
    Gracz(){
        super(true);
        this.zdrowie=100;
    }
    @Override
    public void interakcja(Okno ok,int x, int y) {
        System.out.println("gracz");
    }
}
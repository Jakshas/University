public class Miecz extends Przedmiot{
    int obrazenia;
    Miecz(){
        super();
        obrazenia=(int)(Math.random() * ((3-2) + 1))+1;
    }
    Miecz(int obrazenia){
        super();
        this.obrazenia=obrazenia;
    }
    @Override
    public void interakcja(Okno ok, int x, int y) {
        int i=0;
        while(i<5&&ok.ekwipunek[i]!=null){
            i++;
        }
        if(i<5){
        ok.ekwipunek[i]=new Miecz(obrazenia);
        ok.plansza[x][y]=new Puste(true);
    }}
}
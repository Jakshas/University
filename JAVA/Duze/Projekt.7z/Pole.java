public class Pole {
    boolean widocznosc;
    Pole(){
        widocznosc=false;
    }
    Pole(boolean widocznosc){
        this.widocznosc=widocznosc;
    }
    public void interakcja(Okno ok,int x, int y){
        System.out.println("Błąd Pole");
    }
}
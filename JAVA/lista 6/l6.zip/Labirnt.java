import java.util.ArrayList;
import java.util.Random;

public class Labirnt {
    ArrayList<Integer>[] sciezki;
    int rozmiar;
    int[] sprawdzone;
    Random r = new Random();

    public Labirnt(int srozmiar)
    {
        this.rozmiar = srozmiar;
        sprawdzone = new int[this.rozmiar * this.rozmiar];
        sciezki = new ArrayList[this.rozmiar * this.rozmiar];
        for (int i = 0; i < rozmiar*rozmiar; i++) { 
            sciezki[i] = new ArrayList<Integer>(); 
        }
        sciezki( 0, 0 );
    }



    private void sciezki(int rzad, int kolumna)
    {
        int index = rzad * this.rozmiar + kolumna;
        sprawdzone[index] = 1;

        ArrayList<Integer> kierunki = new ArrayList<Integer>();

        if(rzad < rozmiar - 1){
            kierunki.add(index + rozmiar);
        }
        if(rzad > 0){
            kierunki.add(index - rozmiar);
        }
        if(kolumna > 0){
            kierunki.add(index - 1);
        } 
        if(kolumna < rozmiar - 1){
            kierunki.add(index + 1);
        }
        while(!kierunki.isEmpty())
        {
            int losowa = Math.abs(r.nextInt()) % kierunki.size(); 
            int droga = kierunki.get(losowa); 

            if( sprawdzone[droga] == 0)
            {
                this.sciezki[index].add(droga);
                this.sciezki[droga].add(index);
                sciezki(droga / rozmiar, droga % rozmiar);
            }
            kierunki.remove(losowa);
        }
    }

    public ArrayList<Integer>[] getPossibilities() { return sciezki; };
}
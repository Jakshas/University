<?php
$IsGetFormData = (isset($_GET["sent"]) && ($_GET["sent"]=="y"));
?>
<!DOCTYPE html>
<html>
    <head>
    </head>
    <body>
    <form action="index.php" method="get">
        Nr. karty
        <input type="text" name="nr"><br>
        Data ważności
        <input type="text" name='data'><br>
        CVC
        <input type="text" name='cvc'><br>
        Imie
        <input type="text" name='imie'><br>
        Nazwisko
        <input type="text" name='nazwisko'><br>
        Adres
        <input type="text" name="adres"><br>
        Nr. telefonu
        <input type="text" name="tel"><br>
        Kwota
        <input type="text" name="kwota"><br>
        <input type="submit" value="Wyślij"><br>
    </form>
    <?php
if ( isset($_GET["nr"]) ):
?>
        Nr. karty: <?php if (preg_match('/^[0-9]{4}-[0-9]{4}-[0-9]{4}-[0-9]{4}$/', $_GET['nr'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        Data ważności:<?php if (preg_match('/^[0-1][0-9]\/[0-2][0-9][0-9][0-9]$/', $_GET['data'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        CVC:<?php if (preg_match('/^\d\d\d$/', $_GET['cvc'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        Imie:<?php if (preg_match('/^[A-Z][a-z]+$/', $_GET['imie'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        Nazwisko:<?php if (preg_match('/^[A-Z][a-z]+$/', $_GET['nazwisko'])){ echo 'ok';}else {echo 'nie ok';} ?><br>
        Adres:<?php if (preg_match('/^[A-Z][a-z]+ [0-9]+ [A-Z][a-z]+$/', $_GET['adres'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        Nr. telefonu:<?php if (preg_match('/^[0-9]{9}$/', $_GET['tel'])){ echo 'ok';}else {echo 'nie ok';}?><br>
        Kwota:<?php if (preg_match('/^[0-9]+$/' ,$_GET['kwota'])){ echo 'ok';}else {echo 'nie ok';}?><br>
    </body>
    <?php
endif;
?>
</html>
let klik=document.getElementById('klik')
klik.onclick=
function() {
    var docs = document.getElementById('img');
    docs.setAttribute("src", "512x512.gif");
    setTimeout(function()
    {
        docs.setAttribute("src", "");
        alert("Gratulacje. Nic sie nie zadziało")
    }
    , 3000);
}